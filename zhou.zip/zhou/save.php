<?php
// 启用错误提示（部署时可关闭）
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: text/plain'); // 设置响应类型

$dataFile = __DIR__ . '/data.json'; // 数据文件路径

// 获取并清理输入数据
$text = isset($_POST['text']) ? trim($_POST['text']) : '';
$note = isset($_POST['note']) ? trim($_POST['note']) : '';
$hidden = isset($_POST['hidden']) ? (bool)$_POST['hidden'] : false;

// 验证必填字段
if (empty($text)) {
    http_response_code(400);
    exit('错误：文本内容不能为空');
}

// 加载现有数据
$entries = [];
if (file_exists($dataFile)) {
    $fileContent = file_get_contents($dataFile);
    $entries = json_decode($fileContent, true) ?? [];
}

// 添加新条目
$newEntry = [
    'id' => uniqid(), // 生成唯一ID用于后续管理
    'text' => htmlspecialchars($text, ENT_QUOTES, 'UTF-8'), // 防止XSS
    'note' => htmlspecialchars($note, ENT_QUOTES, 'UTF-8'),
    'hidden' => $hidden,
    'time' => date('Y-m-d H:i:s')
];

array_push($entries, $newEntry);

// 保存数据
try {
    $result = file_put_contents(
        $dataFile,
        json_encode($entries, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
    );
    
    if ($result === false) {
        throw new Exception('文件写入失败');
    }
    
    echo 'OK'; // 返回成功响应
} catch (Exception $e) {
    http_response_code(500);
    exit('服务器错误：' . $e->getMessage());
}
