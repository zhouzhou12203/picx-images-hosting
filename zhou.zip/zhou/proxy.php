<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
readfile('12203data.json');
exit;
